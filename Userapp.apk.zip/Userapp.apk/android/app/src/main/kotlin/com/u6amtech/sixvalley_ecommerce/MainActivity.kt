package com.u6amtech.flutter_sixvalley_ecom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
